Link selected input with mail
CRUD mail, contact, users and folders
