export class FolderDTO{
    userId!: string;
    folderId!: string;
    folderName!: string;
}