export class ContactDTO{
    id!: string;
    userId!: string;
    name!: string;
    mails!: string;
}